package skeleton;

public class NexmoException extends RuntimeException {

  public NexmoException(String message) {
    super(message);
  }
}
