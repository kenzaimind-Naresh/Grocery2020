a=func();
b=z;
for (a++; i < 10; i++) { alert(i); }

var z=1;
g=2;
for (; i < 10; i++) { alert(i); }

var a = 2;
for (var i = 1; i < 10; i++) { alert(i); }
