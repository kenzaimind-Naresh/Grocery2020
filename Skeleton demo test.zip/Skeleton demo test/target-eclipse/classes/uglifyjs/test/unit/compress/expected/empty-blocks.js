function bar(){return--x}function foo(){while(bar());}function mak(){for(;;);}var x=5
