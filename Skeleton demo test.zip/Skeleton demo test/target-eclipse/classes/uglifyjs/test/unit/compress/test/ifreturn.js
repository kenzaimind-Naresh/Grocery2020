function a(b) {
	if (b == 1) {
		return 2;
	} else {
		return 17;
	}

	return 3;
}